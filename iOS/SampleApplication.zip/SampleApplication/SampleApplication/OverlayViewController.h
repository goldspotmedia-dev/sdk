//
//  OverlayViewController.h
//  SampleApplication
//
//  Created by GoldSpot Media on 2015/04/01.
//  Copyright (c)2015 GoldSpot Media, All rights reserved.
//

#import <UIKit/UIKit.h>
#import "GSMMovieManager.h"

@interface OverlayViewController : UIViewController <UIScrollViewDelegate, GSMMovieDelegate>
{
    IBOutlet UIScrollView* _scrollview;
}
- (IBAction) btnBack:(id)sender;
@end
