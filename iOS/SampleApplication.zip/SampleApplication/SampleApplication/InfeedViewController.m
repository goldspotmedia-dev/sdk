//
//  InfeedViewController.m
//  SampleApplication
//
//  Created by GoldSpot Media on 2015/04/01.
//  Copyright (c)2015 GoldSpot Media, All rights reserved.
//

#import "InfeedViewController.h"
#import "SampleApplicationConstants.h"

@interface InfeedViewController ()

@end

@implementation InfeedViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    self.view.frame = [[UIScreen mainScreen] bounds];
    _scrollview.contentSize = CGSizeMake([[UIScreen mainScreen] bounds].size.width, self.view.frame.size.height*3);
    _scrollview.delegate = self;
    
    /* GSM AdRequest */
    float w = self.view.frame.size.width;
    float h = w/16*9;
    
    NSMutableDictionary *param = [NSMutableDictionary dictionary];
    NSMutableDictionary *setting = [NSMutableDictionary dictionary];
    setting[@"zone"] = kGSM_Zone;
    setting[@"adtype"] = @(kGSM_AdType_Infeed);
    setting[@"defaultorientation"] = @(kGSM_Orientaion_DependDevice);
    setting[@"x"] = @"0";
    setting[@"y"] = @"800";
    setting[@"w"] = [NSString stringWithFormat:@"%f", w];
    setting[@"h"] = [NSString stringWithFormat:@"%f", h];
    setting[@"progresscolor"] = [UIColor colorWithRed:0 green:204 blue:255 alpha:1.0];
    
    param[@"ad"] = setting;
    GSMMovieManager.manager.delegate = self;
    [GSMMovieManager.manager setUseIDFA:YES];
    [GSMMovieManager.manager request:param];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (BOOL)shouldAutorotate
{
    return YES;
}

- (void) dealloc
{
    GSMMovieManager.manager.delegate = nil;
    [GSMMovieManager.manager removeZone:kGSM_Zone];
    
    [super dealloc];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction) btnBack:(id)sender
{
    [self dismissViewControllerAnimated:YES completion:nil];
}

#pragma mark -
#pragma mark UIScrollViewDelegate

- (void) scrollViewDidScroll:(UIScrollView *)scrollView
{
    [GSMMovieManager.manager scrollViewDidScroll:kGSM_Zone];
}

#pragma mark -
#pragma mark GSMMovieDelegate

- (void)gsmPrepared:(NSString*)zone adtype:(GSM_AD_TYPE)adtype
{
    ALog(@"");
    if ([kGSM_Zone compare:zone] == NSOrderedSame) {
        [_scrollview addSubview:[GSMMovieManager.manager getZoneView:kGSM_Zone]];
        [GSMMovieManager.manager setRootViewController:self zoneId:zone];
        [GSMMovieManager.manager showAd:kGSM_Zone];
    }
}

- (void) gsmPlayStart:(NSString*)zone adtype:(GSM_AD_TYPE)adtype
{
    ALog(@"");
}

- (void) gsmPlayEnd:(NSString*)zone adtype:(GSM_AD_TYPE)adtype
{
    ALog(@"");
}

- (void) gsmErrorOccured:(NSString*)zone adtype:(GSM_AD_TYPE)adtype error:(NSError*)error
{
    ALog(@"");
    NSMutableString *msg = [NSMutableString string];
    switch (error.code) {
        case kGSM_Error_Unknown:
            msg = [NSMutableString stringWithFormat:@"想定外のエラーが発生しました。\r %@", error.description];
            break;
        case kGSM_Error_IncorrectParameter:
            msg = [NSMutableString stringWithString:@"広告表示用パラメータが正しくセットされていません。"];
            break;
        case kGSM_Error_Disconnected:
            msg = [NSMutableString stringWithString:@"サーバとの接続が切れました。"];
            break;
        case kGSM_Error_Timeout:
            msg = [NSMutableString stringWithString:@"サーバとの接続ができませんでした。"];
            break;
        case kGSM_Error_NotPrepare:
            msg = [NSMutableString stringWithString:@"指定した広告枠は読み込みが完了していません。"];
            break;
        case kGSM_Error_Parse:
            msg = [NSMutableString stringWithString:@"サーバから不正なデータを取得しました。"];
            break;
        default:
            break;
    }
    
    UIAlertView *alert =
    [[UIAlertView alloc] initWithTitle:@"Errror" message:msg
                              delegate:self
                     cancelButtonTitle:@"OK" otherButtonTitles:nil];
    [alert show];
}

- (void) gsmNoAvailableAd:(NSString*)zone  adtype:(GSM_AD_TYPE)adtype
{
    ALog(@"");
    UIAlertView *alert =
    [[UIAlertView alloc] initWithTitle:@"No Ad" message:@"有効な広告がありませんでした"
                              delegate:self
                     cancelButtonTitle:@"OK" otherButtonTitles:nil];
    [alert show];
}

@end
