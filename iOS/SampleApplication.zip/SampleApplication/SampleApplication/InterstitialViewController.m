//
//  InterstitialViewController.m
//  SampleApplication
//
//  Created by GoldSpot Media on 2015/04/01.
//  Copyright (c)2015 GoldSpot Media, All rights reserved.
//

#import "InterstitialViewController.h"
#import "SampleApplicationConstants.h"

@interface InterstitialViewController ()

@end

@implementation InterstitialViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    /* GSM AdRequest */
    NSMutableDictionary *param = [NSMutableDictionary dictionary];
    NSMutableDictionary *setting = [NSMutableDictionary dictionary];
    setting[@"zone"] = kGSM_Zone;
    setting[@"adtype"] = @(kGSM_AdType_Interstitial);
    setting[@"defaultorientation"] = @(kGSM_Orientaion_DependDevice);
    setting[@"x"] = @"0";
    setting[@"y"] = @"0";
    setting[@"w"] = [NSString stringWithFormat:@"%f", [UIScreen mainScreen].bounds.size.width];
    setting[@"h"] = [NSString stringWithFormat:@"%f", [UIScreen mainScreen].bounds.size.height];
    
    param[@"ad"] = setting;
    GSMMovieManager.manager.delegate = self;
    [GSMMovieManager.manager setUseIDFA:YES];
    [GSMMovieManager.manager request:param];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (BOOL)shouldAutorotate
{
    return YES;
}

- (void) dealloc
{
    GSMMovieManager.manager.delegate = nil;
    [GSMMovieManager.manager removeZone:kGSM_Zone];
    
    [super dealloc];
}

- (IBAction) btnBack:(id)sender
{
    [self dismissViewControllerAnimated:YES completion:nil];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

#pragma mark -
#pragma mark GSMMovieDelegate

- (void)gsmPrepared:(NSString*)zone adtype:(GSM_AD_TYPE)adtype
{
    ALog(@"");
    if ([kGSM_Zone compare:zone] == NSOrderedSame) {
        [GSMMovieManager.manager showAd:kGSM_Zone];
    }
}

- (void) gsmPlayStart:(NSString*)zone adtype:(GSM_AD_TYPE)adtype
{
    ALog(@"");
}

- (void) gsmPlayEnd:(NSString*)zone adtype:(GSM_AD_TYPE)adtype
{
    ALog(@"");
}

- (void) gsmErrorOccured:(NSString*)zone adtype:(GSM_AD_TYPE)adtype error:(NSError*)error
{
    ALog(@"");
    NSMutableString *msg = [NSMutableString string];
    switch (error.code) {
        case kGSM_Error_Unknown:
            msg = [NSMutableString stringWithFormat:@"想定外のエラーが発生しました。\r %@", error.description];
            break;
        case kGSM_Error_IncorrectParameter:
            msg = [NSMutableString stringWithString:@"広告表示用パラメータが正しくセットされていません。"];
            break;
        case kGSM_Error_Disconnected:
            msg = [NSMutableString stringWithString:@"サーバとの接続が切れました。"];
            break;
        case kGSM_Error_Timeout:
            msg = [NSMutableString stringWithString:@"サーバとの接続ができませんでした。"];
            break;
        case kGSM_Error_NotPrepare:
            msg = [NSMutableString stringWithString:@"指定した広告枠は読み込みが完了していません。"];
            break;
        case kGSM_Error_Parse:
            msg = [NSMutableString stringWithString:@"サーバから不正なデータを取得しました。"];
            break;
        default:
            break;
    }
    
    UIAlertView *alert =
    [[UIAlertView alloc] initWithTitle:@"Errror" message:msg
                              delegate:self
                     cancelButtonTitle:@"OK" otherButtonTitles:nil];
    [alert show];
}

- (void) gsmNoAvailableAd:(NSString*)zone  adtype:(GSM_AD_TYPE)adtype
{
    ALog(@"");
    UIAlertView *alert =
    [[UIAlertView alloc] initWithTitle:@"No Ad" message:@"有効な広告がありませんでした"
                              delegate:self
                     cancelButtonTitle:@"OK" otherButtonTitles:nil];
    [alert show];
}

@end
