//
//  ViewController.m
//  SampleApplication
//
//  Created by GoldSpot Media on 2015/04/01.
//  Copyright (c)2015 GoldSpot Media, All rights reserved.
//


#import "ViewController.h"
#import "InfeedViewController.h"
#import "InterstitialViewController.h"
#import "OverlayViewController.h"

#define kTag_Btn_Infeed         1
#define kTag_Btn_Interstitial   2
#define kTag_Btn_Overlay        3

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction) btnShowAd:(id)sender
{
    NSInteger tag = ((UIButton*)sender).tag;
    UIViewController *vc = nil;
    switch (tag) {
        case kTag_Btn_Infeed:
            vc = [[[InfeedViewController alloc] initWithNibName:@"InfeedViewController" bundle:[NSBundle mainBundle]]autorelease];
            break;
            
        case kTag_Btn_Interstitial:
            vc = [[[InterstitialViewController alloc] initWithNibName:@"InterstitialViewController" bundle:[NSBundle mainBundle]]autorelease];
            break;
            
        case kTag_Btn_Overlay:
            vc = [[[OverlayViewController alloc] initWithNibName:@"OverlayViewController" bundle:[NSBundle mainBundle]]autorelease];
            break;
            
        default:
            break;
    }
    
    if (vc) {
        [self presentViewController:vc animated:YES completion:nil];
    }
}

@end
