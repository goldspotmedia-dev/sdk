//
//  GSMMovieManager.h
//  GSM Video AdNetwork SDK
//

#import <Foundation/Foundation.h>
#import "GSMConsts.h"
#import <UIKit/UIKit.h>

/**
 * GSM Movie Manager
 */
@interface GSMMovieManager : NSObject
{
}

/** delegate */
@property (nonatomic, assign) id delegate;

//唯一のインスタンスを返す
+ (GSMMovieManager*)manager;

//サーバへ広告リクエスト
- (void) request:(NSDictionary*)adsSettings;

//JSON形式(VAST)のデータから広告生成
- (void) createAdFromJSONData:(NSData*)jsonData adsSettings:(NSDictionary*)adsSettings;

//XML形式(VAST)のデータから広告生成
- (void) createAdFromXmlData:(NSData*)xmlData  adsSettings:(NSDictionary*)adsSettings;

//指定された広告枠のView取得
- (UIView*) getZoneView:(NSString*)zoneId;

//指定された広告枠の削除
- (void) removeZone:(NSString*)zoneId;

//指定された広告の表示
- (void) showAd:(NSString*)zoneId;

//指定した広告の再生(infeed枠のみ有効）
- (void) playMovie:(NSString*)zoneId;

//指定した広告の一時停止(infeed枠のみ有効）
- (void) pauseMovie:(NSString*)zoneId;

// IDFAを送信するかどうか
- (void) setUseIDFA:(BOOL)useIDFA;

// 指定したゾーンで全画面表示を行ったかどうか
- (BOOL) isInterstitialShown:(NSString *)zoneId;

/**
 * 指定したゾーンにスクロールを伝搬させる
 * 
 * UIScrollViewのサブクラス内にアドを表示する場合、inview（可視状態; アドの50%以上が見えている状態）判定を行うため、[id<UIScrollViewDelegate> scrollViewDidScroll:]のイベントをアプリケーション側でハンドリングし、現在追加されているアド（= [[GSMMovieManager manager] getZoneView:]にて取得したUIView）に伝搬させる必要があります<br />
 * アドタイプ:"infeed"のときのみ利用されます<br />
 *
 * @param zoneId ゾーンID
 */
- (void) scrollViewDidScroll:(NSString*)zoneId;

/**
 * 指定したゾーンにRootViewControllerを設定する
 *
 * RootViewControllerとは、アドを表示する画面のトップレベルビューを指します<br />
 * ここで設定したRootViewControllerは、アドタイプ:"infeed"のときのみ利用されます<br />
 * <br />
 * ex1)<br />
 * UINavigationViewControllerの2画面目にアドを表示する場合、<br />
 * RootViewController = 2画面目のUIViewController<br />
 * <br />
 * ex2)<br />
 * UITabBarControllerの3つ目のタブにアドを表示する場合、<br />
 * RootViewController = 3つ目のタブのUIViewController<br />
 * <br />
 * ex3)<br />
 * UITableViewの中段のセル内にアドを表示する場合、<br />
 * RootViewController = UITableViewController<br />
 * <br />
 * ex4)<br />
 * UIScrollViewの下方にアドを表示する場合、RootViewController = UIScrollViewを管理するUIViewController<br />
 * <br />
 * ex5)<br />
 * Single View Applicationの場合、RootViewController = メインのUIViewController
 *
 * @param rootViewController アドを表示する画面のトップレベルビューコントローラ
 * @param zoneId ゾーンID
 */
- (void) setRootViewController:(UIViewController *)rootViewController zoneId:(NSString *)zoneId;

/**
 * GSMMovieManagerの終了処理
 */
- (void)terminate;

@end

//アプリ側で実装するDelegate
@protocol GSMMovieDelegate <NSObject>
@optional

//エラー発生
- (void) gsmErrorOccured:(NSString*)zone adtype:(GSM_AD_TYPE)adtype error:(NSError*)error;

//動画再生準備完了
- (void) gsmPrepared:(NSString*)zone adtype:(GSM_AD_TYPE)adtype;

//動画の再生開始
- (void) gsmPlayStart:(NSString*)zone adtype:(GSM_AD_TYPE)adtype;

//動画の再生終了
- (void) gsmPlayEnd:(NSString*)zone adtype:(GSM_AD_TYPE)adtype;

//有効な広告がなかった
- (void) gsmNoAvailableAd:(NSString*)zone adtype:(GSM_AD_TYPE)adtype;

//(Interstitial)動画画面起動
- (void) gsmShowInterstitial:(NSString*)zone adtype:(GSM_AD_TYPE)adtype;

//(Interstitial)動画画面終了
- (void) gsmCloseInterstitial:(NSString*)zone adtype:(GSM_AD_TYPE)adtype;

//(Infeed/Overlay)動画画面終了
- (void) gsmClose:(NSString *)zone adtype:(GSM_AD_TYPE)adtype;

/**
 * LPのURLを返す
 * 
 * SDKでは、デフォルトではsafariでLPのURLをオープンしますが、アプリケーションによってはナビゲーションの中で表示したいこともあるであろうことを考慮し、requestのパラメータとして setting[@"urlCallback"] = @(YES) と設定することにより、LPのURLをコールバックします
 * 
 * @param zone ゾーンID
 * @param adtype アドタイプ
 * @param url LPのURL
 */
- (void) gsmClickThrough:(NSString*)zone adtype:(GSM_AD_TYPE)adtype url:(NSString *)url;

@end
