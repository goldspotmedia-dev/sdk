//
//  GSMConsts.h
//  GSM Video AdNetwork SDK
//

typedef enum {
    kGSM_AdType_Default = 0,
    kGSM_AdType_Infeed,
    kGSM_AdType_Interstitial,
    kGSM_AdType_Overlay
} GSM_AD_TYPE;

typedef enum {
    kGSM_EventType_None = 0,
    kGSM_EventType_Prepared,
    kGSM_EventType_PlayStart,
    kGSM_EventType_PlayEnd,
	kGSM_EventType_Rewind,
    kGSM_EventType_NoAvailableAd,
    kGSM_EventType_ShowAd,
    kGSM_EventType_CloseAd,
    kGSM_EventType_Muted,
    kGSM_EventType_Unmuted,
    kGSM_EventType_MovieTapped,
    kGSM_EventType_OrieantationChange,
    kGSM_EventType_ExitFullscreen,
	kGSM_EventType_ClickThrough,
    kGSM_EventType_ErrorOccured,
    kGSM_EventType_BannerViewActionShouldBegin,
    kGSM_EventType_BannerViewActionDidFinish,
    kGSM_EventType_InstructClickThrough
} GSM_EVENT_TYPE;

typedef enum {
    kGSM_Error_Unknown = 0,
    kGSM_Error_IncorrectParameter,
    kGSM_Error_Disconnected,
    kGSM_Error_Timeout,
    kGSM_Error_NotPrepare,
    kGSM_Error_Parse
}GSM_ERROR_CODE;

typedef enum {
    kGSM_ControllMode_Playing = 0,
    kGSM_ControllMode_Pausing,
    kGSM_ControllMode_StillFrame,
    kGSM_ControllMode_PlayEnd,
	kGSM_ControllMode_NotPlayed // for AVViewFooter indicate ad prepared but not played yet.
}GSM_CONTROLL_MODE;

typedef enum {
    kGSM_Orientaion_Default=0,
    kGSM_Orientaion_Portrait,
    kGSM_Orientaion_Landscape,
    kGSM_Orientaion_DependDevice
}GSM_ORIENTATION;

