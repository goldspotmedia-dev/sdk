//
//  ViewController.h
//  SampleApplication
//
//  Created by GoldSpot Media on 2015/04/01.
//  Copyright (c)2015 GoldSpot Media, All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

- (IBAction) btnShowAd:(id)sender;

@end

