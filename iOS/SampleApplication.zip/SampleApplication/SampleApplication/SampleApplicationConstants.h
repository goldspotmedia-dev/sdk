//
//  SampleApplicationConstants.h
//  SampleApplication
//
//  Created by GoldSpot Media on 2015/04/01.
//  Copyright (c)2015 GoldSpot Media, All rights reserved.
//


#define kGSM_Zone @"1"
